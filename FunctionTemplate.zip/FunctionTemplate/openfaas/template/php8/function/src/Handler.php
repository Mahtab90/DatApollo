<?php

namespace App;

/**
 * Class Handler
 * @package App
 */
class Handler
{
    /**
     * @param string $data
     * @return string
     */
    public function handle(string $data): string
    {
        return $data;
    }
}
