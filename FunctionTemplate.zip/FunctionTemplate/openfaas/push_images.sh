docker push mashahh/collocate_results
docker push mashahh/itemset_generation
docker push mashahh/rule_generation
