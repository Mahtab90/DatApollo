def cloud_function(json_input):
    input1 = json_input["input1"]
    
    # Processing

    # return the result
    res = {
        "input1": input1
    }
    return res
