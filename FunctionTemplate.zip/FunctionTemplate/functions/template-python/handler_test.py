from .handler import handle

# Test for handler to automate testing when building function with OpenFaaS CLI.
def test_handle():
    pass
